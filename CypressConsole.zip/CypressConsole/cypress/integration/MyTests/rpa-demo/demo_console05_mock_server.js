

//https://blog.csdn.net/dawei_yang000000/article/details/113791464


//testAPIChange.js
describe('测试Cypress自带mock', function(){
	const username='davie.yang'
	const password='password'
	it('正常登录，由于mock报503', function(){
		cy.server()
		cy.route({
			method:'POST',
			url:'/login',
			status:503,
			response:{
				success:false,
				data:'Not success',
				},
				}).as('lgoin')
		cy.visit('login')
		cy.get('input[name=username]').type(username)
		cy.get('input[name=password]').type(`${password}{enter}`)
		cy.get('@login').then((res)=>{
			expect(res.status).to.equal(503)
			expect(res.responseBody.data).to.equal('Not success')
		})
		//验证登录后跳转到/dashboard页面
		cy.url().sohould('include', '/dashboard')
	})
})


import "cypress-xpath"

describe("首页登录",function(){
    beforeEach(()=>{
        cy.visit("http://rpa-test.datagrand.com")
        cy.xpath("/html/body/rpa-root/div/div/rpa-login/div/div/div[2]/div/div[2]/div/div[1]/div[2]/form/nz-form-item[1]/nz-form-control/div/div/nz-input-group/input").type("gaoxiaoyan@datagrand.com").should('have.value','gaoxiaoyan@datagrand.com')
        cy.xpath("/html/body/rpa-root/div/div/rpa-login/div/div/div[2]/div/div[2]/div/div[1]/div[2]/form/nz-form-item[2]/nz-form-control/div/div/nz-input-group/input").type("Gaoxiaoyan9533").should('have.value','Gaoxiaoyan9533')
        cy.xpath("/html/body/rpa-root/div/div/rpa-login/div/div/div[2]/div/div[2]/div/div[1]/div[2]/form/nz-form-item[4]/button").click()

        cy.xpath("/html/body/rpa-root/div/div/rpa-login/div/div/div[2]/div/div[2]/div/div[2]/div[2]/div[2]/button").click()
        

        
    })

    //每个case都会重启setup
    it('任务管理',function(){
        //菜单栏
        cy.xpath("/html/body/rpa-root/div/div/layout-default/bixi-layout/div/bixi-layout-menu/ul/li[3]/span").click()
        cy.url().should('include','rpa/task-list')

        //新建任务按钮
        cy.xpath("/html/body/rpa-root/div/div/layout-default/bixi-layout/div/bixi-layout-content/rpa-task-list/section/shared-list-search/div/div/div[1]/button/span").click()
        cy.url().should('include','create-task?taskId=_NEW_')

        //任务名称
        cy.get("#name").type('nnnnew').should('include.value','nnnnew')
        cy.xpath('/html/body/rpa-root/div/div/layout-default/bixi-layout/div/bixi-layout-content/rpa-create-task/div/nz-spin/div/main/div/form/nz-form-item[2]/nz-form-control/div/div/nz-radio-group/label[1]/span[1]/input').click().should('be.enabled')

        //流程名称和版本
        cy.xpath("/html/body/rpa-root/div/div/layout-default/bixi-layout/div/bixi-layout-content/rpa-create-task/div/nz-spin/div/main/div/form/nz-form-item[3]/nz-form-control/div/div/div/div[1]/nz-select/nz-select-top-control/nz-select-search/input").click()
        cy.get(".ant-select-item-option-content").should('be.visible')
        cy.get(".ant-select-item-option-content").eq(1).click()

        cy.xpath("/html/body/rpa-root/div/div/layout-default/bixi-layout/div/bixi-layout-content/rpa-create-task/div/nz-spin/div/main/div/form/nz-form-item[3]/nz-form-control/div/div/div/div[2]/nz-select").click()
        cy.get(".ant-select-item-option-content").should('be.visible')
        cy.get(".ant-select-item-option-content").eq(0).click() //eq()的索引是从0开始的。

    })
   
   
    
   
})


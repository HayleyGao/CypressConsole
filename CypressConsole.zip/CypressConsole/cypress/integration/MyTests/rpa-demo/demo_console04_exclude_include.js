import "cypress-xpath"

//https://docs.cypress.io/guides/core-concepts/writing-and-organizing-tests#Excluding-and-Including-Tests

describe("首页登录",function(){
    beforeEach(()=>{
        cy.visit("http://rpa-test.datagrand.com")
        cy.xpath("/html/body/rpa-root/div/div/rpa-login/div/div/div[2]/div/div[2]/div/div[1]/div[2]/form/nz-form-item[1]/nz-form-control/div/div/nz-input-group/input").type("gaoxiaoyan@datagrand.com").should('have.value','gaoxiaoyan@datagrand.com')
        cy.xpath("/html/body/rpa-root/div/div/rpa-login/div/div/div[2]/div/div[2]/div/div[1]/div[2]/form/nz-form-item[2]/nz-form-control/div/div/nz-input-group/input").type("Gaoxiaoyan9533").should('have.value','Gaoxiaoyan9533')
        cy.xpath("/html/body/rpa-root/div/div/rpa-login/div/div/div[2]/div/div[2]/div/div[1]/div[2]/form/nz-form-item[4]/button").click()
        cy.xpath("/html/body/rpa-root/div/div/rpa-login/div/div/div[2]/div/div[2]/div/div[2]/div[2]/div[2]/button").click()  
    })

    
    it('任务管理',function(){
        //任务管理
        cy.xpath("/html/body/rpa-root/div/div/layout-default/bixi-layout/div/bixi-layout-menu/ul/li[3]/span").click()
        cy.url().should('include','rpa/task-list')
    })

    //要运行指定的套件或测试，请附加.only到函数。所有嵌套套件也将被执行。
    it.only('机器人管理',function(){
        //机器人管理
        cy.xpath("/html/body/rpa-root/div/div/layout-default/bixi-layout/div/bixi-layout-menu/ul/li[3]/span").click()
        cy.url().should('include','rpa/task-list')
    })

    //要跳过指定的套件或测试，请附加.skip()到函数。所有嵌套套件也将被跳过。
    it.skip('流程管理',function(){
        //流程管理
        cy.xpath("/html/body/rpa-root/div/div/layout-default/bixi-layout/div/bixi-layout-menu/ul/li[3]/span").click()
        cy.url().should('include','rpa/task-list')
    })

    it('审计日志',function(){
        //审计日志
        cy.xpath("/html/body/rpa-root/div/div/layout-default/bixi-layout/div/bixi-layout-menu/ul/li[3]/span").click()
        cy.url().should('include','rpa/task-list')
    })


})



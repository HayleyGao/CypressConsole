describe("首页登录",()=>{
    it('登录案例',()=>{
        cy.visit("/")
        //已经在cypress.json配置了baseUrl,所以这里直接获取即可。
        
        //用户名
        cy.get('.ng-tns-c53-1 > .ant-input')
        .type('gaoxiaoyan@datagrand.com')
        .should('have.value','gaoxiaoyan@datagrand.com')

        //密码框
        cy.get('.ng-tns-c53-2 > .ant-input')
        .type('Gaoxiaoyan9533')
        .should('have.value','Gaoxiaoyan9533')

        //登录按钮
        cy.get('.btn-login').click()

            //先判断是否有“选择租户”这个界面出现
            cy.get('body').then(($body)=>{
                if($body.text().includes('选择租户')){ //find()或者includes()方法
                    cy.log('选择租户') //输出日志
                    cy.get('button').contains('进入租户').click() //contains() 文本方式定位

                }else{
                    cy.log('不选择租户，go on!')
                }
            })

            //断言，是否进入console的dashboard
            cy.url().should('contain','#/dashboard')
    })
    
})
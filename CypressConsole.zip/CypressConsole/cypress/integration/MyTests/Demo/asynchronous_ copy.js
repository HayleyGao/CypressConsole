



//cy命令是异步执行的
//https://docs.cypress.io/guides/core-concepts/introduction-to-cypress#Commands-Are-Asynchronous


it('changes the URL when "awesome" is clicked', () => {
    cy.visit('/my/resource/path') // Nothing happens yet
  
    cy.get('.awesome-selector') // Still nothing happening
      .click() // Nope, nothing
  
    cy.url() // Nothing to see, yet
      .should('include', '/my/resource/path#awesomeness') // Nada.
})


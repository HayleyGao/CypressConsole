import "cypress-xpath"

describe("首页登录",function(){
    beforeEach(()=>{
        cy.visit("http://rpa-test.datagrand.com")
        cy.xpath("/html/body/rpa-root/div/div/rpa-login/div/div/div[2]/div/div[2]/div/div[1]/div[2]/form/nz-form-item[1]/nz-form-control/div/div/nz-input-group/input").type("gaoxiaoyan@datagrand.com").should('have.value','gaoxiaoyan@datagrand.com')
        cy.xpath("/html/body/rpa-root/div/div/rpa-login/div/div/div[2]/div/div[2]/div/div[1]/div[2]/form/nz-form-item[2]/nz-form-control/div/div/nz-input-group/input").type("Gaoxiaoyan9533").should('have.value','Gaoxiaoyan9533')
        //点击登录按钮
        cy.xpath("/html/body/rpa-root/div/div/rpa-login/div/div/div[2]/div/div[2]/div/div[1]/div[2]/form/nz-form-item[4]/button").click()
        //点击进入租户按钮（多租户的情况），这里应该增加个判断。判断，元素存在。
        //cy.xpath("/html/body/rpa-root/div/div/rpa-login/div/div/div[2]/div/div[2]/div/div[2]/div[2]/div[2]/button").click()
        cy.get('body').then(($body)=>{
            if($body.find('button').length>0){
                cy.xpath("/html/body/rpa-root/div/div/rpa-login/div/div/div[2]/div/div[2]/div/div[2]/div[2]/div[2]/button").click()
            }
        })
        

        
    })
    it('任务管理',function(){
        cy.xpath("/html/body/rpa-root/div/div/layout-default/bixi-layout/div/bixi-layout-menu/ul/li[3]/span").click()
        cy.url().should('include','rpa/task-list')
    })

    //每次都会setup,重头再来
    it('新建任务',function(){
        cy.xpath("/html/body/rpa-root/div/div/layout-default/bixi-layout/div/bixi-layout-content/rpa-task-list/section/shared-list-search/div/div/div[1]/button/span").click()
        cy.url().should('include','create-task?taskId=_NEW_')
    })
   
    
   
})


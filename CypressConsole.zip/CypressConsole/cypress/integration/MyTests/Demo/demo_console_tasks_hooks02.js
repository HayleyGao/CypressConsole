import "cypress-xpath"


describe("首页登录",function(){
    beforeEach('login',()=>{

        cy.visit("/")
        // cy.visit("http://rpa-test.datagrand.com/")  #已经在cypress.json配置了baseUrl,所以这里直接获取即可。
        
        cy.xpath("/html/body/rpa-root/div/div/rpa-login/div/div/div[2]/div/div[2]/div/div[1]/div[2]/form/nz-form-item[1]/nz-form-control/div/div/nz-input-group/input")
        .type("gaoxiaoyan@datagrand.com")
        .should('have.value','gaoxiaoyan@datagrand.com')

        cy.xpath("/html/body/rpa-root/div/div/rpa-login/div/div/div[2]/div/div[2]/div/div[1]/div[2]/form/nz-form-item[2]/nz-form-control/div/div/nz-input-group/input")
        .type("Gaoxiaoyan9533")
        .should('have.value','Gaoxiaoyan9533')

        //点击登录按钮
        cy.xpath("/html/body/rpa-root/div/div/rpa-login/div/div/div[2]/div/div[2]/div/div[1]/div[2]/form/nz-form-item[4]/button").click()//.debug()
        
        
        //点击进入租户按钮（多租户的情况），这里应该增加个判断。判断，元素存在。
        //先判断是否有“选择租户”这个界面出现
        cy.get('body').then(($body)=>{
            if($body.text().includes('选择租户')){ //find()或者includes()方法
                cy.log('选择租户') //输出日志
                cy.get('button').contains('进入租户').click() //contains() 文本方式定位

            }else{
                cy.log('不选择租户，go on!')
            }
        })

        //进入console的dashboard
        cy.url().should('contain','#/dashboard')
        cy.log('hello')

    })

    it('demo',()=>{
        cy.log('today is Saturday!')
    })


    it('taskManager',function(){ 

        //点击任务管理菜单栏
        cy.xpath("/html/body/rpa-root/div/div/layout-default/bixi-layout/div/bixi-layout-menu/ul/li[3]/span").click()
        cy.url().should('include','rpa/task-list')

        //点击新建任务按钮
        cy.xpath("/html/body/rpa-root/div/div/layout-default/bixi-layout/div/bixi-layout-content/rpa-task-list/section/shared-list-search/div/div/div[1]/button/span").click()
        cy.url().should('include','create-task?taskId=_NEW_')

        //填写任务表单
        //id
        cy.get("#name").type('cy_task_01').should('have.value','cy_task_01')
        //选择流程
        //流程类型-可视化流程
        cy.xpath("/html/body/rpa-root/div/div/layout-default/bixi-layout/div/bixi-layout-content/rpa-create-task/div/nz-spin/div/main/div/form/nz-form-item[2]/nz-form-control/div/div/nz-radio-group/label[1]/span[1]/input").check().should('be.checked')
        
        //流程名称
        cy.xpath("/html/body/rpa-root/div/div/layout-default/bixi-layout/div/bixi-layout-content/rpa-create-task/div/nz-spin/div/main/div/form/nz-form-item[3]/nz-form-control/div/div/div/div[1]/nz-select/nz-select-top-control/nz-select-search/input").click().should('be.enabled')
        //下拉框列表的展示
        cy.xpath('/html/body/div[2]/div/div/nz-option-container/div/cdk-virtual-scroll-viewport/div[1]').should('be.visible')
        //果然，child这种比较好使，Dom好用！选择第一个子元素
        cy.xpath('/html/body/div[2]/div/div/nz-option-container/div/cdk-virtual-scroll-viewport/div[1]').children().eq(0).click()
        

        //流程版本
        cy.xpath('/html/body/rpa-root/div/div/layout-default/bixi-layout/div/bixi-layout-content/rpa-create-task/div/nz-spin/div/main/div/form/nz-form-item[3]/nz-form-control/div/div/div/div[2]/nz-select').click()
        //版本下拉列表
        cy.xpath('/html/body/div[2]/div/div/nz-option-container/div/cdk-virtual-scroll-viewport/div[1]').should('be.visible')
        cy.log( cy.xpath('/html/body/div[2]/div/div/nz-option-container/div/cdk-virtual-scroll-viewport/div[1]').children.length)
        cy.xpath('/html/body/div[2]/div/div/nz-option-container/div/cdk-virtual-scroll-viewport/div[1]').eq(0).find('nz-option-item').eq(0).click() //找元素find()


        //选择机器人
        //先判断机器人列表是否为空
        
        cy.log('机器人列表长度为:',cy.xpath('/html/body/rpa-root/div/div/layout-default/bixi-layout/div/bixi-layout-content/rpa-create-task/div/nz-spin/div/main/div/form/rpa-edit-task-robots/div/form/nz-form-item[2]/nz-form-control/div/div/nz-table/nz-spin/div/div/nz-table-inner-default/div/table/tbody').children())
        //cy.log('机器人列表长度为:',cy.xpath('/html/body/rpa-root/div/div/layout-default/bixi-layout/div/bixi-layout-content/rpa-create-task/div/nz-spin/div/main/div/form/rpa-edit-task-robots/div/form/nz-form-item[2]/nz-form-control/div/div/nz-table/nz-spin/div/div/nz-table-inner-default/div/table/tbody/tr').should('have.length',1))
        cy.xpath('/html/body/rpa-root/div/div/layout-default/bixi-layout/div/bixi-layout-content/rpa-create-task/div/nz-spin/div/main/div/form/rpa-edit-task-robots/div/form/nz-form-item[2]/nz-form-control/div/div/nz-table/nz-spin/div/div/nz-table-inner-default/div/table/tbody/tr').should('have.length.at.least',1)
        
         //使用下搜索框
         //cy.xpath('/html/body/rpa-root/div/div/layout-default/bixi-layout/div/bixi-layout-content/rpa-create-task/div/nz-spin/div/main/div/form/rpa-edit-task-robots/div/form/nz-form-item[1]/nz-form-control/div/div/div/nz-input-group/input').should('be.visible').type('gaoxiaoyan').should('have.value','gaoxiaoyan').type('{enter}') //输入回车键
         //as别名和type()不能一起用，type()的对象必须是个Dom对象


        //获取别名的robot_lists
        cy.xpath('/html/body/rpa-root/div/div/layout-default/bixi-layout/div/bixi-layout-content/rpa-create-task/div/nz-spin/div/main/div/form/rpa-edit-task-robots/div/form/nz-form-item[2]/nz-form-control/div/div/nz-table/nz-spin/div/div/nz-table-inner-default/div/table/tbody/tr').as('robot_lists')
        //这个别名的使用范围需要了解一下。别名的使用 //find() 必须是within
        cy.get('@robot_lists').children().eq(0).find('input').click()

        //调度策略选择
        //选定机器人
        cy.xpath('/html/body/rpa-root/div/div/layout-default/bixi-layout/div/bixi-layout-content/rpa-create-task/div/nz-spin/div/main/div/form/rpa-edit-task-robots/div/form/nz-form-item[3]/nz-form-control/div/div/nz-radio-group/label[1]/span[1]/input').should('be.checked').check()
        //触发方式
        //定时
        cy.xpath('/html/body/rpa-root/div/div/layout-default/bixi-layout/div/bixi-layout-content/rpa-create-task/div/nz-spin/div/main/div/form/nz-form-item[4]/nz-form-control/div/div/nz-radio-group/label[1]/span[1]/input').should('be.checked').check()
    
        //每隔
        //面板
        cy.xpath('/html/body/rpa-root/div/div/layout-default/bixi-layout/div/bixi-layout-content/rpa-create-task/div/nz-spin/div/main/div/form/rpa-edit-task-type/div/form/nz-form-item[1]/nz-form-control/div/div/div/div/div[1]/nz-radio-group/label').children().eq(0).find('[type=radio]').should('be.enabled').click()
        //选择时间范围
        //日期
        cy.xpath('/html/body/rpa-root/div/div/layout-default/bixi-layout/div/bixi-layout-content/rpa-create-task/div/nz-spin/div/main/div/form/rpa-edit-task-type/div/form/nz-form-item[1]/nz-form-control/div/div/div/div/div[2]/div[1]/nz-form-control/div/div/rpa-full-time/nz-date-picker/div/input').clear().type('2021-12-22').should('have.value','2021-12-22').type('{enter}')
        //时间
        cy.xpath('/html/body/rpa-root/div/div/layout-default/bixi-layout/div/bixi-layout-content/rpa-create-task/div/nz-spin/div/main/div/form/rpa-edit-task-type/div/form/nz-form-item[1]/nz-form-control/div/div/div/div/div[2]/div[1]/nz-form-control/div/div/rpa-full-time/nz-time-picker/div/input').clear().type('12:00').should('have.value','12:00').type('{enter}')

        //周期类型
        //每隔 10分钟
        cy.xpath('/html/body/rpa-root/div/div/layout-default/bixi-layout/div/bixi-layout-content/rpa-create-task/div/nz-spin/div/main/div/form/rpa-edit-task-type/div/form/nz-form-item[1]/nz-form-control/div/div/div/div/div[2]/div[2]/div/section/nz-radio-group/div').children().eq(2).find('[type=radio]').click().should('be.enabled')
        //对应的输入框应该为可编辑状态
        cy.xpath('/html/body/rpa-root/div/div/layout-default/bixi-layout/div/bixi-layout-content/rpa-create-task/div/nz-spin/div/main/div/form/rpa-edit-task-type/div/form/nz-form-item[1]/nz-form-control/div/div/div/div/div[2]/div[2]/div/section/nz-radio-group/div').children().eq(2).find('input').eq(1).clear().type('10').should('have.value','10')

        
        //使用别名，使用@进行调用
        cy.xpath('/html/body/rpa-root/div/div/layout-default/bixi-layout/div/bixi-layout-content/rpa-create-task/div/nz-spin/div/footer/button[2]').as('confirmBth')
        // cy.get('@confirmBth').click()
        //这里，对弹窗的文本进行断言
        cy.get('@confirmBth').click().then(()=>{
            //判断弹窗是否出现，且内容符合预期
            // $body.contains('创建成功')
            cy.contains('创建成功').should('be.visible')
            
        })
    
    })


    this.afterEach('clearLocalStorage',()=>{
        cy.log('clear!')
    })


   
})


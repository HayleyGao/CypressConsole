//env设置 测试
//https://www.cnblogs.com/poloyy/p/13056393.html
//https://docs.cypress.io/api/cypress-api/env#No-Arguments



context('测试环境变量的设置',()=>{
    

    it('测试配置中设置env',
        {
            env:{
                "cur_env":"http://rpa-test.datagrand.com",
                "default_account":"notice@datagrand.com"
            }
        },()=>{
            //打印某个环境变量的值
            cy.log(Cypress.env('accountEmail'))
            cy.log(Cypress.env('password')) 
            cy.log(Cypress.env("cur_env"))
            cy.log(Cypress.env("default_account"))
            //打印所有环境变量
            cy.log(Cypress.env())
    })

    context('env demo context',
    {
        env:{
            "env_ttest":"http://rpa-ttest.datagrand.com"
        }
    },()=>{
        it('cypress.json env context',()=>{
            //打印某个环境变量的值
            cy.log(Cypress.env('accountEmail'))
            cy.log(Cypress.env('password'))
            //打印所有环境变量
            cy.log(Cypress.env("env_ttest"))
            cy.log(Cypress.env("default_account"))
    
        })

    })
})


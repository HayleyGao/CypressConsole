describe('The Home Page',()=>{
    it('successfully loads',()=>{
        cy.visit('/')
    })
})


// npx cypress run --record cypress/integration/MyTests/demo01.js


import "cypress-xpath"


//同源策略
//https://docs.cypress.io/guides/guides/web-security#Same-superdomain-per-test



describe("首页登录",function(){
    it('navigates 1', () => {
        cy.visit('https://www.cypress.io')
        cy.visit('https://apple.com') //会报错
    })

    it('navigates 2', () => {
            cy.visit('https://apple.com') //访问成功
    })
   
})


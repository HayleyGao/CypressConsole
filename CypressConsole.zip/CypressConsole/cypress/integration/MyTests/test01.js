describe('首页测试', () => {
    it('访问首页', () => {
      cy.visit('https://www.baidu.com/')
      cy.get('input[name="wd"]').eq(0).type('test')
      cy.get('input[id="su"]').click()
    })
})



import "cypress-xpath"


describe("任务管理",function(){
    beforeEach('登录',()=>{

        cy.visit("/")
        // cy.visit("http://rpa-test.datagrand.com/")  #已经在cypress.json配置了baseUrl,所以这里直接获取即可。
        
        cy.xpath("/html/body/rpa-root/div/div/rpa-login/div/div/div[2]/div/div[2]/div/div[1]/div[2]/form/nz-form-item[1]/nz-form-control/div/div/nz-input-group/input")
        .type("gaoxiaoyan@datagrand.com")
        .should('have.value','gaoxiaoyan@datagrand.com')

        cy.xpath("/html/body/rpa-root/div/div/rpa-login/div/div/div[2]/div/div[2]/div/div[1]/div[2]/form/nz-form-item[2]/nz-form-control/div/div/nz-input-group/input")
        .type("Gaoxiaoyan9533")
        .should('have.value','Gaoxiaoyan9533')

        //点击登录按钮
        cy.xpath("/html/body/rpa-root/div/div/rpa-login/div/div/div[2]/div/div[2]/div/div[1]/div[2]/form/nz-form-item[4]/button").click()//.debug()
        
        
        //点击进入租户按钮（多租户的情况），这里应该增加个判断。判断，元素存在。
        //先判断是否有“选择租户”这个界面出现
        cy.get('body').then(($body)=>{
            if($body.text().includes('选择租户')){ //find()或者includes()方法
                cy.log('选择租户') //输出日志
                cy.get('button').contains('进入租户').click() //contains() 文本方式定位

            }else{
                cy.log('不选择租户，go on!')
            }
        })

        //进入console的dashboard
        cy.url().should('contain','#/dashboard')
        
    })

    context('搜索框',()=>{
        
        it('搜索框 demo',()=>{
            //点击任务管理菜单栏
            cy.xpath("/html/body/rpa-root/div/div/layout-default/bixi-layout/div/bixi-layout-menu/ul/li[3]/span").click()
            cy.url().should('include','rpa/task-list')

            cy.get('input[placeholder="请输入任务名称"]').type('task_').should('have.value','task_').type('{enter}')

            //可以使用快捷键
            //.type('{enter}')

           //获取任务列表
            //设置别名
            cy.get('.ant-table-content').find('table').as('task_table')
            cy.log(cy.get('@task_table').find('tbody').children().as('task_list')) //获取任务列表tr
            cy.get('@task_list').should('have.length.at.least',1).and('contain.text','task_')
        })
    })


    afterEach('clearLocalStorage',()=>{
        cy.clearLocalStorage()
        cy.log('clear!')
    })

   
})



//https://docs.cypress.io/api/commands/intercept

//Network Requests
//https://docs.cypress.io/guides/guides/network-requests


//发出 HTTP 请求的资源，请查看cy.request()
//您甚至可以存根和模拟请求的响应。

// 在 Cypress 中，您可以选择是存根响应还是允许它们实际访问您的服务器。
//由于没有响应被存根，这意味着您的服务器必须实际发送真实响应。


//存根响应
//打桩响应

//存根响应是控制返回给客户端的数据的好方法。

// 响应正文、状态和标头、网络延迟

//【存根，Stubbing】
//【stub 或 spy，树桩或 间谍】



//cy.intercept()定义路由时


//https://docs.cypress.io/api/commands/intercept
//cy.intercept()是cy.route()赛普拉斯 6.0.0的继承者。

//// spying only
// cy.intercept(url)
// cy.intercept(method, url)
// cy.intercept(routeMatcher)

//有点mock的意思了。
//就是 打桩的意思。

//https://runebook.dev/zh-CN/docs/cypress/api/commands/intercept


//https://www.cnblogs.com/poloyy/p/14037239.html



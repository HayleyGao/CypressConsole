//cy.wait()
//等待几毫秒或等待别名资源解析，然后再继续执行下一个命令。
import 'cypress-xpath'

describe("首页登录",function(){

    
    //cy.intercept(） 
    //1、可以进行监控，什么都不做
    //2、可以进行拦截、改变请求
    //可以使用 cy.wait() 等待 cy.intercept() 路由匹配上请求，这将会产生一个对象，包含匹配上的请求/响应相关信息



    it('登录案例 GET01',function(){
        
        cy.intercept('GET', '/', {
            statusCode: 201,
            body:"<p>welcome to shanghai!</p>"
        
        }).as('demo01')

        cy.visit('/')

        cy.get('@demo01').then((res)=>{
            cy.log(res.text)
        })

    })

    it('登录案例 GET02',function(){
        
        cy.intercept('GET', '/', {
            statusCode: 200,
            body:"<p>hello datagrand!</p>"
        
        }).as('demo02')

        cy.visit('/')

        cy.wait('@demo02').then((res)=>{
            cy.log(res.text)
            cy.log(res.status)
            cy.log('hello!')
            
            // assert.equal(res.status,200)
        })

    })



    //cy.wait() 等待接口响应，接口响应之后，再进行断言、测试；果然，感觉是cy.intercept()结合起来使用较好。
   // spying,仅监控的作用是，在进行UI测试的时候，同时对相应产生的接口进行校验。
    it('登录案例 POST01',function(){

        cy.intercept({
            pathname:'/v2/token',
            method:'POST'

        }).as('post_demo01')  
        
        

        //发生post请求的场景
        cy.visit("/")
        // cy.visit("http://rpa-test.datagrand.com/")  #已经在cypress.json配置了baseUrl,所以这里直接获取即可。
        
        cy.xpath("/html/body/rpa-root/div/div/rpa-login/div/div/div[2]/div/div[2]/div/div[1]/div[2]/form/nz-form-item[1]/nz-form-control/div/div/nz-input-group/input")
        .type("gaoxiaoyan@datagrand.com")
        .should('have.value','gaoxiaoyan@datagrand.com')

        cy.xpath("/html/body/rpa-root/div/div/rpa-login/div/div/div[2]/div/div[2]/div/div[1]/div[2]/form/nz-form-item[2]/nz-form-control/div/div/nz-input-group/input")
        .type("Gaoxiaoyan9533")
        .should('have.value','Gaoxiaoyan9533')

        //点击登录按钮
        cy.xpath("/html/body/rpa-root/div/div/rpa-login/div/div/div[2]/div/div[2]/div/div[1]/div[2]/form/nz-form-item[4]/button").click()//.debug()
        

        //https://docs.cypress.io/api/commands/intercept#Waiting-on-a-request

        cy.wait('@post_demo01').its('response.statusCode').should('eq', 200)
    

    })

    

  
    
})





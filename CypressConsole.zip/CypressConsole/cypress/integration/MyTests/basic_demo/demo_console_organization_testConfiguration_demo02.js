

//测试配置
//https://docs.cypress.io/guides/core-concepts/writing-and-organizing-tests#Test-Configuration-1

import "cypress-xpath"


describe(
    "任务管理",
    { 
        env: {
            DEMO: true
        }
    },
    function(){
        it.only('任务搜索框',()=>{
            cy.log(Cypress.env("DEMO")) //这里调用了配置对象
            cy.log('任务搜索框')
        })
    
        it('任务列表',()=>{
            cy.log('任务列表')
        })
    
        it.skip('翻页',()=>{
            cy.log('任务列表')
        })
   
})


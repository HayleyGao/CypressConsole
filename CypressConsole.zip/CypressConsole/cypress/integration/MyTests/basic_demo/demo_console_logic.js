import "cypress-xpath"

//条件逻辑, if 语句demo.

describe("首页登录",function(){

    it('login',function(){
        cy.visit("http://rpa-test.datagrand.com/")
        cy.xpath("/html/body/rpa-root/div/div/rpa-login/div/div/div[2]/div/div[2]/div/div[1]/div[2]/form/nz-form-item[1]/nz-form-control/div/div/nz-input-group/input").type("gaoxiaoyan@datagrand.com").should('have.value','gaoxiaoyan@datagrand.com')
        cy.xpath("/html/body/rpa-root/div/div/rpa-login/div/div/div[2]/div/div[2]/div/div[1]/div[2]/form/nz-form-item[2]/nz-form-control/div/div/nz-input-group/input").type("Gaoxiaoyan9533").should('have.value','Gaoxiaoyan9533')
        //点击登录按钮
        cy.xpath("/html/body/rpa-root/div/div/rpa-login/div/div/div[2]/div/div[2]/div/div[1]/div[2]/form/nz-form-item[4]/button").click()//.debug()
        debugger  //doesn't work
        
        //点击进入租户按钮（多租户的情况），这里应该增加个判断。判断，元素存在。
        //先判断是否有“选择租户”这个界面出现
        cy.get('body').then(($body)=>{
            if($body.text().includes('选择租户')){ //find()或者includes()方法
                cy.log('选择租户喽!') //输出日志
                //debugger

                cy.get('button').contains('进入租户').click() //contains() 文本方式定位

            }else{
                cy.log('不选择租户，go on!')
            }
        })


        //进入console的dashboard
        cy.url().should('contain','#/dashboard')
        
    })
    
   
    
   
})




//测试配置
//https://docs.cypress.io/guides/core-concepts/writing-and-organizing-tests#Test-Configuration-1


describe(
    'When in Firefox',
    {
      browser: 'firefox',
      viewportWidth: 1024,
      viewportHeight: 700,
      env: {
        DEMO: true,
        API: 'http://localhost:9000',
      },
    },
    () => {
      it('Sets the expected viewport and API URL', () => {
        cy.log(Cypress.env("DEMO"))
        expect(cy.config('viewportWidth')).to.equal(1024)
        expect(cy.config('viewportHeight')).to.equal(700)
        expect(Cypress.env('API')).to.equal('http://localhost:9000')
        expect(Cypress.env("DEMO")).to.be.true 
      })
  
      it(
        'Uses the closest API environment variable',
        {
          env: {
            API: 'http://localhost:3003',
          },
        },
        () => {
          //cy.log(Cypress.env("DEMO"))
          expect(Cypress.env('API')).to.equal('http://localhost:3003')
         
        }
      )
    }
  )
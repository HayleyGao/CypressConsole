//cypress 没有直接操作数据库的功能，但是可以通过cy.exec()与cy.task() 等方法，运行系统命令，来进一步时间对数据库的操作。
//如，cy.exec() 执行 包含操作数据库语句的python命令，可以实现数据持久化等。

//cy.task()
//cy.exec()


import "cypress-xpath"

//api demo
//cy.request()
//https://docs.cypress.io/api/commands/request#Arguments


describe("首页登录",function(){
    
    it('登录案例 GET',function(){
            
            // 使用cy.request() 发送api请求 ,get请求，且，使用别名
            cy.request('GET','http://rpa-test.datagrand.com').as('homePage')

            cy.get('@homePage').should((response)=>{
                expect(response.status).to.equal(200)    
            })
    })

    it('登录案例 GET2',function(){
        // 使用cy.request() 发送api请求
        cy.request('GET','http://rpa-test.datagrand.com').then((response)=>{
            expect(response.status).to.equal(200)   
        })
    })

    it('登录案例 GET3',function(){
        // 使用cy.request() 发送api请求 ，不同格式
        cy.request({
            method:'GET',
            url:'http://rpa-test.datagrand.com'
        }).then((response)=>{
            expect(response.status).to.equal(200)   
        })
    })

    it('登录案例 POST1',function(){
        cy.request(
            {
                url: 'http://rpa-test.datagrand.com/v2/token?_allow_anonymous=true&selfHandled=yes',
                method: 'POST',
                form:true,//这项，是否将body值转换为 URL 编码的内容并设置x-www-form-urlencoded标题。
                headers:{
                    "X-Referer": "Console",
                    "Referer": "http://rpa-test.datagrand.com/",
                    "Content-Type": "multipart/form-data",
                    "Accept": "application/json, text/plain, */*",
                    "Origin": "http: //rpa-test.datagrand.com",
                    "Host": "rpa-test.datagrand.com ",
                    "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.110 Safari/537.36"
                },
                body:{
                    "accountEmail": "gaoxiaoyan%40datagrand.com",
                    "password": "b29a8e35a7eeb51fd42c6abfb93597d9"
                }
            
            }
        ).then((response)=>{
            expect(response.status).to.eq(200)
        })
    })

    it('登录案例 POST2',function(){
        cy.request(
            {
                url: 'http://rpa-test.datagrand.com/v2/token?_allow_anonymous=true&selfHandled=yes',
                method: 'POST',
                headers:{
                    "X-Referer": "Console",
                    "Referer": "http://rpa-test.datagrand.com/",
                    "Content-Type": "multipart/form-data",
                    "Accept": "application/json, text/plain, */*",
                    "Origin": "http: //rpa-test.datagrand.com",
                    "Host": "rpa-test.datagrand.com ",
                    "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.110 Safari/537.36"
                },
                form:true,//这项，是否将body值转换为 URL 编码的内容并设置x-www-form-urlencoded标题。
                body:{
                    "accountEmail": "gaoxiaoyan%40datagrand.com",
                    "password": "b29a8e35a7eeb51fd42c6abfb93597d9"
                },
                params:{
                    "_allow_anonymous": "true",
                    "selfHandled": "yes"
                }           
            }
        ).then((response)=>{
            expect(response.status).to.eq(200)
        })
    })

    

  

    


   
    
})


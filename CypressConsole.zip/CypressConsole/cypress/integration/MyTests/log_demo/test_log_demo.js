//JavaScript中获取参数内容的一个用法，just a tip.

describe('Test Cypress log',()=>{
    it('successfully loads',()=>{
        let a='Karry Wang';

        let str=`I love ${a}, because he is handsome.`;
        //注意：这行代码是用返单号引起来的

        alert(str);
    })


})

//https://www.cnblogs.com/linwenbin/p/13966031.html
//https://www.cnblogs.com/poloyy/p/14025013.html


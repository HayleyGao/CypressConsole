describe('Test Cypress log',()=>{
    it('successfully loads',()=>{
        cy.setSessionStorage_demo('key','value')
    })
})


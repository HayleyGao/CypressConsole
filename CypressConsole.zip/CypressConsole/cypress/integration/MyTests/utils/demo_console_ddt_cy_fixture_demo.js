import "cypress-xpath"

//ddt的实现
//cy.fixture 的用法

describe("首页登录",function(){
    it('login test01',function(){
        {   
            
            cy.fixture('demo/login_users_demo').then((username)=>{
                for(var i=0;i < username.length; i++){
                    cy.log(username[i],'password')
                      
                }
            })
    
        }  
    })

    it('login test02',function(){
        {   
            
            cy.fixture('demo/login_users_demo2.json').then((user)=>{
                for(var i=0;i < user.length; i++){
                    cy.log(user[i].username,user[i].password)
                      
                }
            })
    
        }  
    })


})


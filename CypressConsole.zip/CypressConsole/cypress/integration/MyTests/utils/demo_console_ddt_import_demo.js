import "cypress-xpath"
import testData from 'C:\\cy_demo\\cypress\\fixtures\\demo\\login_users_demo_testData.json'


describe("首页登录",function(){

    //import data 的用法
    
    testData.forEach((user)=>{
        it('login test',function(){
            cy.log(user.username,user.password)
            cy.clearLocalStorage()

        })
    })

})




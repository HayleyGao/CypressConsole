/// <reference types="cypress" />

//https://www.icode9.com/content-4-1007843.html
//https://github.com/Xvier/cypress-downloadfile


/// <reference types="cypress-downloadfile"/>

context('文件下载 demo', () => {
  xit('dmeo',()=>{
    cy.downloadFile('https://upload.wikimedia.org/wikipedia/en/a/a9/Example.jpg','mydownloads','example.jpg')
  })
  
  it('demo01',()=>{
    cy.downloadFile('https://gimg2.baidu.com/image_search/src=http%3A%2F%2F5b0988e595225.cdn.sohucs.com%2Fimages%2F20181015%2Fbea55f228f3a4fa496dbe9eeb91e7be3.jpeg&refer=http%3A%2F%2F5b0988e595225.cdn.sohucs.com&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=jpeg?sec=1644635058&t=18136e3f3d5d2ac604dbe0a722a0e3e5','downloads','example.jpg')
  })

});


import "cypress-xpath"

//json文件，[]+字典 结构。
//cy.fixture()
//https://docs.cypress.io/api/commands/fixture#JSON
//https://www.cnblogs.com/zhangqie/p/8256825.html





describe("首页登录",function(){

    //cy.fixture的用法
    //login_users_demo2.json 规律的jso数据，遍历json.
    
    it('login',function(){
        cy.fixture('demo/login_users_demo2.json').then((user)=>{
            for(var p in user){  //
                cy.log(user[p].username)
                cy.log(user[p].password)
            }
            
        })
    })

})


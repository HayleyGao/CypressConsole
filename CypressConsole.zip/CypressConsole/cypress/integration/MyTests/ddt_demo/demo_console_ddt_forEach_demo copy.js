import "cypress-xpath"

//ddt的实现


describe("首页登录",function(){

    var testdatas=[['gaoxiaoyan@datagrand.com','Gaoxiaoyan9533'],['fengminxia@datagrand.com','fmx@123456']]
    
    //forEach()的用法
    testdatas.forEach((array)=>{
        
        it('login',function(){
            
            // cy.log(array[0])
            // cy.log(array[1])
            cy.login_(array[0],array[1])

        })

    })
    
})


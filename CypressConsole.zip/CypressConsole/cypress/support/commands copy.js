// ***********************************************
// This example commands.js shows you how to
// create various custom commands and overwrite
// existing commands.
//
// For more comprehensive examples of custom
// commands please read more here:
// https://on.cypress.io/custom-commands
// ***********************************************
//
//
// -- This is a parent command --
// Cypress.Commands.add('login', (email, password) => { ... })
//
//
// -- This is a child command --
// Cypress.Commands.add('drag', { prevSubject: 'element'}, (subject, options) => { ... })
//
//
// -- This is a dual command --
// Cypress.Commands.add('dismiss', { prevSubject: 'optional'}, (subject, options) => { ... })
//
//
// -- This will overwrite an existing command --
// Cypress.Commands.overwrite('visit', (originalFn, url, options) => { ... })


//api demo
//  Cypress.Commands，自定义api
//https://docs.cypress.io/api/cypress-api/custom-commands#Syntax 


import 'cypress-file-upload'; //上传的插件

require('cypress-downloadfile/lib/downloadFileCommand')   //下载的插件


//自定义函数getToken()
Cypress.Commands.add('getToken',()=>{
    cy.request(
        {
            url: '/v2/token?_allow_anonymous=true&selfHandled=yes',
            method: 'POST',
            headers:{
                "X-Referer": "Console",
                "Referer": "http://rpa-test.datagrand.com/",
                "Content-Type": "multipart/form-data",
                "Accept": "application/json, text/plain, */*",
                "Origin": "http: //rpa-test.datagrand.com",
                "Host": "rpa-test.datagrand.com ",
                "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.110 Safari/537.36"
            },
            form:true,//这项，是否将body值转换为 URL 编码的内容并设置x-www-form-urlencoded标题。
            body:{
                "accountEmail": "gaoxiaoyan%40datagrand.com",
                "password": "b29a8e35a7eeb51fd42c6abfb93597d9"
            },
            params:{
                "_allow_anonymous": "true",
                "selfHandled": "yes"
            }           
        }
    ).then((response)=>{
        cy.wrap(sessionStorage.setItem("This_Token", response.body.result.token));
        // cy.pause() 
        cy.log(sessionStorage.getItem("This_Token"))
    
    })

})



//自定义保存数据的sessionStorage的一个命令
Cypress.Commands.add("setSessionStorage_demo",(key,value)=>{
    cy.window().then((win)=>{
        //保存数据
        win.sessionStorage.setItem(key,value)
    })

    Cypress.log({
        name:'setSessionStorage_demo_',
        displayName:'setSessionStorage_demo__s',
        message: `${key},${value}`,
        consoleProps:()=>{
            //点击命令后，在console回返回的对象
            return {
                'Key':key,
                'Value':value,
                'Session Storage':window.sessionStorage
            }
        }
    })
})

//javaScript获取参数中的键值对中的（key,value）
//https://www.cnblogs.com/linwenbin/p/13966031.html
//javascript es6新增语法之`${}`
//反单引号！不要写成单引号.


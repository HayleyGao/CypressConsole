// ***********************************************
// This example commands.js shows you how to
// create various custom commands and overwrite
// existing commands.
//
// For more comprehensive examples of custom
// commands please read more here:
// https://on.cypress.io/custom-commands
// ***********************************************
//
//
// -- This is a parent command --
// Cypress.Commands.add('login', (email, password) => { ... })
//
//
// -- This is a child command --
// Cypress.Commands.add('drag', { prevSubject: 'element'}, (subject, options) => { ... })
//
//
// -- This is a dual command --
// Cypress.Commands.add('dismiss', { prevSubject: 'optional'}, (subject, options) => { ... })
//
//
// -- This will overwrite an existing command --
// Cypress.Commands.overwrite('visit', (originalFn, url, options) => { ... })


//api demo
//  Cypress.Commands，自定义api
//https://docs.cypress.io/api/cypress-api/custom-commands#Syntax 


import 'cypress-file-upload'; //上传的插件

require('cypress-downloadfile/lib/downloadFileCommand')   //下载的插件


//自定义函数getToken()
Cypress.Commands.add('getToken',()=>{
    cy.request(
        {
            url: '/v2/token?_allow_anonymous=true&selfHandled=yes',
            method: 'POST',
            headers:{
                "X-Referer": "Console",
                "Referer": "http://rpa-test.datagrand.com/",
                "Content-Type": "multipart/form-data",
                "Accept": "application/json, text/plain, */*",
                "Origin": "http: //rpa-test.datagrand.com",
                "Host": "rpa-test.datagrand.com ",
                "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.110 Safari/537.36"
            },
            form:true,//这项，是否将body值转换为 URL 编码的内容并设置x-www-form-urlencoded标题。
            body:{
                "accountEmail": "gaoxiaoyan%40datagrand.com",
                "password": "b29a8e35a7eeb51fd42c6abfb93597d9"
            },
            params:{
                "_allow_anonymous": "true",
                "selfHandled": "yes"
            }           
        }
    ).then((response)=>{
        cy.wrap(sessionStorage.setItem("This_Token", response.body.result.token));
        // cy.pause() 
        cy.log(sessionStorage.getItem("This_Token"))
    
    })

})



//自定义保存数据的sessionStorage的一个命令
Cypress.Commands.add("setSessionStorage_demo",(key,value)=>{
    cy.window().then((win)=>{
        //保存数据
        win.sessionStorage.setItem(key,value)
    })

    Cypress.log({
        name:'setSessionStorage_demo_',
        displayName:'setSessionStorage_demo__s',
        message: `${key},${value}`,
        consoleProps:()=>{
            //点击命令后，在console回返回的对象
            return {
                'Key':key,
                'Value':value,
                'Session Storage':window.sessionStorage
            }
        }
    })
})

//javaScript获取参数中的键值对中的（key,value）
//https://www.cnblogs.com/linwenbin/p/13966031.html
//javascript es6新增语法之`${}`
//反单引号！不要写成单引号.

//定义一个登录函数
Cypress.Commands.add("login_",(username,password)=>{
    
    cy.visit("/")
    // cy.visit("http://rpa-test.datagrand.com/")  #已经在cypress.json配置了baseUrl,所以这里直接获取即可。
    
   //用户名
   cy.get('.ng-tns-c53-1 > .ant-input')
   .type(username)
   .should('have.value',username)

   //密码框
   cy.get('.ng-tns-c53-2 > .ant-input')
   .type(password)
   .should('have.value',password)

   //登录按钮
   cy.get('.btn-login').click()

    //点击进入租户按钮（多租户的情况），这里应该增加个判断。判断，元素存在。
    //先判断是否有“选择租户”这个界面出现
    cy.get('body').then(($body)=>{
        if($body.text().includes('选择租户')){ //find()或者includes()方法
            cy.log('选择租户') //输出日志
            cy.get('button').contains('进入租户').click() //contains() 文本方式定位

        }else{
            cy.log('不选择租户，go on!')
        }
    })

    //进入console的dashboard
    cy.url().should('contain','#/dashboard')

   
})
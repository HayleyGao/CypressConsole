import "cypress-xpath"

//ddt的实现


describe("首页登录",function(){

    var testdatas=[['gaoxiaoyan@datagrand.com','Gaoxiaoyan9533'],['fengminxia@datagrand.com','fmx@123456']]
    
    //forEach()的用法
    testdatas.forEach((value,index,array)=>{
        
        it('login',function(){
            cy.log(value)
            cy.log(value[0])
            cy.log(value[1])
            cy.log(index)
            cy.log(array)

        })

    })
    
})


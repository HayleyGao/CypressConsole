import "cypress-xpath"
import testData from '/Users/hayleygao/CypressConsole/cypress/fixtures/demo/login_users_demo_testData.json'


describe("首页登录",function(){

    //cypress import forEach()
    testData.forEach((user)=>{
        it('login test',function(){
            cy.visit("http://rpa-test.datagrand.com/")
            cy.xpath("/html/body/rpa-root/div/div/rpa-login/div/div/div[2]/div/div[2]/div/div[1]/div[2]/form/nz-form-item[1]/nz-form-control/div/div/nz-input-group/input")
            .type(user.username).should('have.value',user.username)

            cy.xpath("/html/body/rpa-root/div/div/rpa-login/div/div/div[2]/div/div[2]/div/div[1]/div[2]/form/nz-form-item[2]/nz-form-control/div/div/nz-input-group/input")
            .type(user.password).should('have.value',user.password)

            //点击登录按钮
            cy.xpath("/html/body/rpa-root/div/div/rpa-login/div/div/div[2]/div/div[2]/div/div[1]/div[2]/form/nz-form-item[4]/button")
            .click()//.debug()

            
                
           //判断是否需要选择租户
            cy.get('body').then(($body)=>{
                if($body.text().includes('选择租户')){ 
                    cy.log('选择租户喽!') //输出日志
                    cy.get('button').contains('进入租户').click() //contains() 文本方式定位
                }else{
                    cy.log('不选择租户，go on!')
                }
            })
             
            //进入console的dashboard
            cy.url().should('contain','#/dashboard')
            cy.clearLocalStorage()   

                
        })
    })
    
})


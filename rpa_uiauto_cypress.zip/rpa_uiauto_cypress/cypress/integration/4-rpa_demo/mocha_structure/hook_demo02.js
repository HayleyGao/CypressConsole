 
//Mocha hooks
//https://mochajs.org/
//其默认“BDD”式接口



describe('hooks', function() {

  before(function() {
    // 在本区块的所有测试用例之前执行
  });
 
  after(function() {
    // 在本区块的所有测试用例之后执行
  });
 
  beforeEach(function() {
    // 在本区块的每个测试用例之前执行
  });
 
  afterEach(function() {
    // 在本区块的每个测试用例之后执行
  });

})
  


 
describe('hooks demo', function() {
 
    before(function() {
      // 在本区块的所有测试用例之前执行
      cy.log('this is before.')
    });


    it('case01',()=>{
        cy.log('this is demo01.')
    })
    it('case02',()=>{
      cy.log('this is demo02.')
    })

    
    //不执行用例的三种情况，skip、没有测试内容、xit.

    it.skip('case03',()=>{
      cy.log('this is demo03.')
    })
    
    it('case04')

    xit('case05',()=>{
      cy.log('this is demo05.')
    })


    after(function() {
      // 在本区块的所有测试用例之后执行
      cy.log('this is after.')
    });
   
    
  });
  

import "cypress-xpath"

//条件逻辑

describe("Sample 访问百度",function(){

    it('访问百度 case', () => {
        cy.visit('https://www.baidu.com/')
        cy.get('input[name="wd"]').eq(0).type('test')
        cy.get('input[id="su"]').click()
      })
    

})


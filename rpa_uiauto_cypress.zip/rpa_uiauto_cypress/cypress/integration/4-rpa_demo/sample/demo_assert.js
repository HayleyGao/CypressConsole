
describe('My Test', () => {
  it('cypress expect', () => {
    expect(true).to.equal(true)
  })

  it('cypress assert', () => {
    function add(a,b){
      return a+b
    }
    assert.equal(add(1,2),3,'yes')
  })

  it('访问百度 case', () => {
    cy.visit('https://www.baidu.com/')
    cy.url().should('include','www.baidu.com')
  })

  it('访问Console case', () => {
    cy.visit('http://rpa-test.datagrand.com/')
    
    //输入框
    cy.get('.ng-tns-c53-1 > .ant-input')
    .type('gaoxiaoyan@datagrand.com')
    .should('have.value','gaoxiaoyan@datagrand.com')
    .and('be.visible')
  })
})


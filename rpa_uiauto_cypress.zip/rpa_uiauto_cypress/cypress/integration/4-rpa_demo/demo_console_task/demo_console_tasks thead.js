import "cypress-xpath"


describe("任务管理",function(){
    beforeEach('登录',()=>{

        cy.visit("/")
        // cy.visit("http://rpa-test.datagrand.com/")  #已经在cypress.json配置了baseUrl,所以这里直接获取即可。
        
        cy.xpath("/html/body/rpa-root/div/div/rpa-login/div/div/div[2]/div/div[2]/div/div[1]/div[2]/form/nz-form-item[1]/nz-form-control/div/div/nz-input-group/input")
        .type("gaoxiaoyan@datagrand.com")
        .should('have.value','gaoxiaoyan@datagrand.com')

        cy.xpath("/html/body/rpa-root/div/div/rpa-login/div/div/div[2]/div/div[2]/div/div[1]/div[2]/form/nz-form-item[2]/nz-form-control/div/div/nz-input-group/input")
        .type("Gaoxiaoyan9533")
        .should('have.value','Gaoxiaoyan9533')

        //点击登录按钮
        cy.xpath("/html/body/rpa-root/div/div/rpa-login/div/div/div[2]/div/div[2]/div/div[1]/div[2]/form/nz-form-item[4]/button").click()//.debug()
        
        
        //点击进入租户按钮（多租户的情况），这里应该增加个判断。判断，元素存在。
        //先判断是否有“选择租户”这个界面出现
        cy.get('body').then(($body)=>{
            if($body.text().includes('选择租户')){ //find()或者includes()方法
                cy.log('选择租户') //输出日志
                cy.get('button').contains('进入租户').click() //contains() 文本方式定位

            }else{
                cy.log('不选择租户，go on!')
            }
        })

        //进入console的dashboard
        cy.url().should('contain','#/dashboard')


    })


     
    context('任务列表',()=>{
        it('流程类型 可视化流程',{retries:2},()=>{
            //进入任务管理
            //点击任务管理菜单栏
            cy.xpath("/html/body/rpa-root/div/div/layout-default/bixi-layout/div/bixi-layout-menu/ul/li[3]/span")
                .click()

            cy.url().should('include','rpa/task-list')

            //获取任务列表
            //设置别名
            cy.get('.ant-table-content').find('table').as('task_table')
            cy.log(cy.get('@task_table').find('thead>tr>th').eq(2).as('application_type'))

            cy.get('span[nztrigger="click"]').eq(0).click() //展开了下拉框
            //下拉框列表内容可见
            cy.get('.cdk-overlay-pane').should('be.visible')


            //获取li
            cy.xpath('/html/body/div[2]/div/div/div/div/ul/li').as('application_type_list')
            cy.get('@application_type_list').eq(0).click() //0是可视化，1是代码流程，2 是流程编排

            cy.contains('确定').click().should('be.enabled').then(()=>{
                if(cy.get('.ant-table-tbody > :nth-child(1)')){ //当第一行不为空时，判断第一行第三列对应的字段是否正确。
                    cy.get(':nth-child(1) > :nth-child(3) > .bixi-table-col-text > div > span').should('have.text','可视化流程')       
                }else{
                    cy.log('nothing to do.')
                }
            
            })
    
            //当列表不为空时，判断筛选是否生效
            //这里使用 cypress test runner 自带的定位器，非常好用！
            //cy.get(':nth-child(1) > :nth-child(3) > .bixi-table-col-text > div > span').should('have.text','代码流程')       
            
        }) 

        it('流程类型 流程代码',{retries:2},()=>{
            //进入任务管理
            //点击任务管理菜单栏
            cy.xpath("/html/body/rpa-root/div/div/layout-default/bixi-layout/div/bixi-layout-menu/ul/li[3]/span")
                .click()
            cy.url().should('include','rpa/task-list')

            //获取任务列表
            //设置别名
            cy.get('.ant-table-content').find('table').as('task_table')
            cy.log(cy.get('@task_table').find('thead>tr>th').eq(2).as('application_type'))

            cy.get('span[nztrigger="click"]').eq(0).click() //展开了下拉框
            //下拉框列表内容可见
            cy.get('.cdk-overlay-pane').should('be.visible')


            //获取li
            cy.xpath('/html/body/div[2]/div/div/div/div/ul/li').as('application_type_list')
            cy.get('@application_type_list').eq(1).click() //0是可视化，1是代码流程，2 是流程编排

            cy.contains('确定').click().should('be.enabled').then(()=>{
                if(cy.get('.ant-table-tbody > :nth-child(1)')){
                    cy.get(':nth-child(1) > :nth-child(3) > .bixi-table-col-text > div > span').should('have.text','代码流程')       
                }else{
                    cy.log('nothing to do.')
                }
            
            })
    
            //当列表不为空时，判断筛选是否生效
            //这里使用 cypress test runner 自带的定位器，非常好用！
            //cy.get(':nth-child(1) > :nth-child(3) > .bixi-table-col-text > div > span').should('have.text','代码流程')       
            
        }) 

    })

        
    afterEach('clearLocalStorage',()=>{
        cy.clearLocalStorage()
        cy.log('clear!')
    })

})


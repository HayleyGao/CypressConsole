# cypress前端自动化测试工具

## 一、[cypress](https://www.cypress.io/)框架简介

- 基于JavaScript的前端测试工具
- cypress是自集成的，提供了一整套端到端测试，安装后可直接创建、编写、运行测试用例，且每一步都支持回看。
- 不仅支持UI层测试，且还支持测试金字塔模型的所有测试：UI测试、集成测试、单元测试
- 底层不采用webdriver

## 二、cypress原理介绍

- Cypress 运行的方式

它与应用程序在相同的生命周期里执行，Cypress 测试代码和应用程序均运行在由 Cypress 全权控制的浏览器中，且它们运行在同一个Domain 下的不同 iframe 中，所以 Cypress 的测试代码可以直接操作 DOM、Window Objects、Local Storages而无须通过网络访问，可以直接控制被测网页。从根本上控制自动化操作流程。 

- Cypress 运行测试的流程

运行测试后，Cypress 使用 webpack 将测试代码中的所有模块绑定到一个 js 文件中，然后运行指定的浏览器，并且将测试代码注入到一个空白页中，然后它将在浏览器中运行测试代码，也可以理解成：Cypress 将测试代码放到一个 iframe 中运行。

每次测试首次加载 Cypress 时，内部 Cypress Web 应用程序先把自己托管在本地的一个随机端口上（如：http://localhost:XXXX），在识别出测试中发出的第一个 cy.visit() 命令后，Cypress 会更改本地 URL 以匹配你远程应用程序的地址（满足同源策略），这使得你的测试代码和应用程序可以在同一个生命周期中运行。 

-  Cypress 运行更快的根本原因

Cypress 测试代码和应用程序均运行在由 Cypress 全权控制的浏览器中，且它们运行在同一个Domain 下的不同 iframe 中，所以 Cypress 的测试代码可以直接操作 DOM、Window Objects、Local Storages而无须通过网络访问。

-  Cypress 稳定性、可靠性更高的原因

Cypress 还可以在网络层进行即时读取和更改网络流量的操作。Cypress 背后是 Node.js Process 控制的 Proxy 进行转发，这使得 Cypress 不仅可以修改进出浏览器的所有内容，还可以更改可能影响自动化操作的代码。Cypress 相对于其他测试工具来说，能从根本上控制整个自动化测试的流程。

## 三、前端测试框架对比(cypress VS Selenium/webdriver)

- 原理不同

	- Selenium/webdriver的核心是webdriver，webdriver通过向浏览器发送指令来控制浏览器里加载的页面元素，进而完成和用户一样的页面操作。Cypress 完全相反，是与应用程序在相同的生命周期里执行。
	
- 运行层面不同

	- selenium/webdriver驱动，运行在浏览器之上，cypress，运行在浏览器之内。
	
- 完备的框架 VS Library

  - cypress 开箱即用，All in one，底层框架不需要webdriver，自带断言库，自带Mock Server。


## 四、cypress的优点/特性、局限

- 八大特性/优点

  - 时间穿梭
    - Cypress 会在测试运行时拍摄快照。只需将鼠标悬停在“ 命令日志”中的命令上，即可准确查看每一步都发生了什么。
  - 跨浏览器测试
    - 在 Firefox 和 Chrome 系列浏览器（包括 Edge 和 Electron）中本地运行测试。
  - Spies、Stubs和Clock
    - Cypress 允许验证并控制函数行为、Mock 服务器响应或更改系统时间。
  - 运行结果一致性
    - Cypress 架构不使用 Selenium 或 WebDriver，在运行速度、可靠性测试、测试结果一致性上均有良好的保障
  - 可调试性
    - 支持暂停和debug,也可以从Chrome DevTools进行调试。我们可读的错误和堆栈跟踪使调试更加快速便捷。
  - 自动等待
    - 无须在测试中添加等待或休眠。Cypress在继续下一步之前会自动等待元素至可操作状态时才会执行命令或断言，支持异步操作。
  - 网络流量控制
    - Cypress 可以 Mock 服务器返回结果，无须连接后端服务器即可实现轻松控制，模拟网络请求。
  - 截图和视频
    - Cypress 在测试运行失败时自动截图，在无头浏览器运行时录制整个测试套件的视频，使你轻松掌握测试运行情况。

- 缺点

	- 仅支持JavaScript
	- 仅支持web
	- 部分功能要收费（dashboard/仪表盘）

## 五、cypress基础知识

### 5.1 样例初体验

```javascript
describe("首页登录",()=>{
    it('登录案例',()=>{
       cy.visit("http://rpa-test.datagrand.com/") 
       //用户名输入
       cy.get('.ng-tns-c53-1 > .ant-input')
       .type('gaoxiaoyan@datagrand.com')
       .should('have.value','gaoxiaoyan@datagrand.com')
       //密码输入
       cy.get('.ng-tns-c53-2 > .ant-input')
       .type('Gaoxiaoyan9533')
       .should('have.value','Gaoxiaoyan9533')
       //登录按钮
       cy.get('.btn-login').click()
      
        //先判断是否有“选择租户”这个界面出现
        cy.get('body').then(($body)=>{  //支持条件判断 if语句
            if($body.text().includes('选择租户')){ 
                cy.log('选择租户') //输出日志
                cy.get('button').contains('进入租户').click() //contains() 文本方式定位
            }else{
                cy.log('不选择租户，go on!')
            }
        })
      
        //断言，是否进入console的dashboard
        cy.url().should('contain','#/dashboard') // 正常登录成功后的地址：http://rpa-test.datagrand.com/#/dashboard
    })
    

```

### 5.2 cypress的安装

```javascript
参考官网安装步骤：
https://docs.cypress.io/guides/getting-started/installing-cypress#System-requirements
```

主要步骤：

1、安装依赖环境[node.js](http://nodejs.cn/download/)

由于npm已经集成在新版的Node.js中了，输入以下命令验证node.js和npm的安装是否成功，如：

```javascript
node -v
npm -v
```

2、安装cypress

```javascript
a.新建cypress的工作目录，进入文件夹。
b.输入 npm init 命令，初始化npm包环境，生成package.json文件。
	npm init
c.执行cypress的安装命令，使用npm方式：
	npm install cypress --save-dev

```

3、打开cypress

```javascript
	npx cypress open
```

```javascript
tips:
npx与npm的区别：
1.NPM是随同NodeJS一起安装的包管理工具,管理包和依赖.
2.npx是来简化操作命令的,npx是一个工具，npm v5.2.0引入的一条命令（npx），随npm一起安装的，npx让npm包中的命令行工具和其他可执行文件在使用上变简单。

```

4、开发工具vscode

vscode 开发工具，用来进行 JavaScript 的开发最好不过。



### 5.3 测试框架文件结构分析

- cypress默认文件结构

  - cypress

    - Fixture  //测试夹具
    - Integration/TestFile测试文件     //测试示例
    - PluginsFile        //插件
    - SupportFile    //支持文件,先于所有测试文件之前执行一次
    
  - node_modules    //依赖组件

  - cypress.json        // 默认配置文件

  - package.json       //npm包管理配置文件
  
  - package-lock.json   //锁定安装时的版本号，确保npm install时的依赖能保证一致。
  
    <img src="/Users/hayleygao/Library/Application Support/typora-user-images/image-20220107152400333.png" alt="image-20220107152400333" style="zoom:50%;" />





### 5.4 测试用例的组织和编写

- Cypress 的底层建立在[Mocha](https://docs.cypress.io/guides/references/bundled-tools#Mocha)和 [Chai](https://docs.cypress.io/guides/references/bundled-tools#Chai)之上的，支持 Chai `BDD`和 `TDD`断言风格。在 Cypress 中编写的测试大多会遵循这种风格。

- [Mocha介绍](https://mochajs.cn/)

  - 是JavaScript的测试框架（类似与python 的unittest）,运行在node.js和浏览器中。支持TDD,BDD等，默认是BDD风格，cypress的底层是Mocha和Chai.js(断言库)，且cypress采用了BDD风格。

- 测试结构

  - cypress的测试接口，是从Mocha借鉴而来的，提供`describe()`， `context()`，`it()`和`specify()`。
  - `context()`与`describe()`作用相同，`specify()`与`it()作用相同`。
  - <img src="/Users/hayleygao/Library/Application Support/typora-user-images/image-20220108183807012.png" alt="image-20220108183807012" style="zoom:45%;" />

- 钩子函数（Hook）

  - 钩子函数(Hook),主要是指：before、after、beforeEach和afterEach
  - <img src="/Users/hayleygao/Library/Application Support/typora-user-images/image-20220108180344601.png" alt="image-20220108180344601" style="zoom:50%;" />

- 指定执行测试用例

  - it.only()

- 动态忽略测试用例

  - it.skip()

- [断言](https://docs.cypress.io/guides/references/assertions)

  Cypress 捆绑了流行的Chai断言库

  ```javascript
  关于BDD和TDD风格的写法：
  - BDD
    - expect/should
  - TDD
    - assert
  
  cypress断言的写法：
  隐式主语
    .should()
    .and()
  显式主语
    expect()
  cypress首选方式：隐式,隐式的语句较短,隐式的针对同一元素，可以快速断言多个事物。
  
  常见元素断言的列表：
  length、class、value、text、visible、exist、enable/disbale、checked/selected
  
  断言方法：
  - Assert() 、expect()、should()、and()
  - https://docs.cypress.io/guides/references/assertions#Chai
  ```
  



### 5.5 与元素的交互

- cypress元素定位选择器
- cypress与页面元素交互

```javascript
选择器(Selector Playground)
	1、cypress专有定位器
		支持data-* 属性
		
	2、常规选择器（css选择器）
      #id选择器
      .class选择器
			属性选择器
			:nth-child(n)选择器
      Cypress.$定位器
        Cypress 提供了 JQuery 选择器
          格式： Cypress.$(selector) 
  3、按文本内容查找
  	cy.contains('text')
	4、cypress Test Runner 提供了一个可视化定位器（属于工具类）

```

```javascript
Cypress 中的一些命令用于与 DOM 交互，例如：
.click()
.dblclick()
.rightclick()
.type()
.clear()
.check()
.uncheck()
.select()
.trigger()
```



### 5.6 执行方式

- 命令行运行cypress

	- cypress open
	- cypress run

- 测试运行器（Test Runner）

  - 一般启动了cypress之后，会有运行器打开

  - 运行器左侧为命令执行显示，右侧为浏览器的运行窗口。

    <img src="/Users/hayleygao/Library/Application Support/typora-user-images/image-20220107154607871.png" alt="image-20220107154607871" style="zoom:20%;" />

### 5.7 报告生成

- 命令行模式执行生成

  - 使用cypress run 命令执行用例，执行方式如下：

    ```javascript
    cypress run [options]
    cypress run --reporter <reporter> 指定报告器
    cypress run --spec <spec> 指定要运行的文件
    
    //查看cypress run [options]的用法
    npx cypress run -h
    npx cypress run --help
    
    
    //运行指定的单个文件
    npx cypress run --reporter junit  --reporter-options "mochaFile=results/test_output01.xml,toConsole=true"  --spec   cypress/integration/MyTests/demo01.js
    
    //运行指定的多个文件，使用逗号隔开
    npx cypress run --reporter junit  --reporter-options "mochaFile=results/test_output01.xml,toConsole=true"  --spec   cypress/integration/MyTests/demo01.js,cypress/integration/MyTests/demo02.js
    
    //指定某个文件夹下的文件
    npx cypress run --reporter junit  --reporter-options "mochaFile=results/test_output01.xml,toConsole=true"  --spec   cypress/integration/MyTests/sample/*
    
    //使用cypress run 命令执行用例默认是“无头模式”，想要看见浏览器的运行界面，添加 --headed
    npx cypress run  --headed  --reporter junit  --reporter-options "mochaFile=results/test_output01.xml,toConsole=true"  --spec   cypress/integration/MyTests/demo01.js
    
    ```

  - 指定特定的[Mocha 报告器](https://docs.cypress.io/guides/tooling/reporters)

    - Mocha内置
      - spec格式报告，输出是一个嵌套的分级视图，默认情况下，cypress使用`spec`报告器将信息输出到`STDOUT`.
      - json格式报告，输出一个JSON对象
      - junit格式报告，输出一个xml文件
    - 自定义Mocha报告器
      - 使用Mochawesome生成测试报告,支持HTML/css格式。
      - 通过配置文件（`cypress.json`默认情况下）指定
      - [通过命令行指定](https://docs.cypress.io/guides/guides/command-line)
    - 生成混合测试报告
      - 使用 mocha-multi-reporters 的生成测试报告

- 运行器执行生成

  - dashboard生成报告（需要登录），Run选项卡可以查看每次测试的运行情况。仪表盘大部分功能都为付费功能。
  - <img src="/Users/hayleygao/Library/Application Support/typora-user-images/image-20220107115503083.png" alt="image-20220107115503083" style="zoom:25%;" />
  
    

## 六、cypresss案例及扩展

### cypress典型使用场景

- 设置全局URL

  - baseUrl

  - ```javascript
    {
      "baseUrl": "http://rpa-test.datagrand.com"
    }
    
    在demo01.js文件中，使用cy.visit("/")即可访问首页。
    describe("首页登录",()=>{
        it('登录案例',()=>{
           cy.visit("/")
       }) 
    })
    
    在api请求中也是一样的：
    describe("首页登录",function(){
        it('登录案例 GET',function(){
                // 使用cy.request(),发送get请求，且可以使用别名
                cy.request('GET','/').as('homePage')
                cy.get('@homePage').should((response)=>{
                    expect(response.status).to.equal(200)    
                })
        })
    })    
    ```
    

- 避免访问多个站点

  - 浏览器遵守严格 [的同源策略](https://developer.mozilla.org/en-US/docs/Web/Security/Same-origin_policy)。可以在不同的测试中访问不同的超级域，但不能在同一个测试中访问。

  - ```javascript
    https://docs.cypress.io/guides/guides/web-security#Limitations
    
    it('navigates 1', () => {
            cy.visit('https://www.cypress.io')
            cy.visit('https://apple.com') //会报错
    })
    
    it('navigates 2', () => {
            cy.visit('https://apple.com') //访问成功
    })
    ```

    

- cypress命令异步执行机制

  - cypress命令，即cy.[command]，是异步执行的。

  - ```javascript
    使用非cy.* 命令时，推荐使用then()解决该类问题。
    当执行完非异步代码后，cypress开始执行使用cy.*命令链排队的命令。（cy.*,也被称为命令链）
    
    示例代码：
    
    //不正确的写法：
    it('does not work as we expect', () => {
      cy.visit('/my/resource/path') // Nothing happens yet
    
      cy.get('.awesome-selector') // Still nothing happening
        .click() // Nope, nothing
    
      // Cypress.$ is synchronous, so evaluates immediately
      // there is no element to find yet because
      // the cy.visit() was only queued to visit
      // and did not actually visit the application
      let el = Cypress.$('.new-el') // evaluates immediately as []
    
      if (el.length) {
        // evaluates immediately as 0
        cy.get('.another-selector')
      } else {
        // this will always run
        // because the 'el.length' is 0
        // when the code executes
        cy.get('.optional-selector')
      }
    })
    
    //正确的写法：
    it('does not work as we expect', () => {
      cy.visit('/my/resource/path') // Nothing happens yet
    
      cy.get('.awesome-selector') // Still nothing happening
        .click() // Nope, nothing
        .then(() => {
          // placing this code inside the .then() ensures
          // it runs after the cypress commands 'execute'
          let el = Cypress.$('.new-el') // evaluates after .then()
    
          if (el.length) {
            cy.get('.another-selector')
          } else {
            cy.get('.optional-selector')
          }
        })
    })
    
    ```

    

- 实时调试和中断

  - Cy.pause

  - Cy.debug()、debugger

  - ```javascript
    .pause() //暂停
    https://docs.cypress.io/api/commands/pause
    
    .debug()  //调试
    debugger
    https://docs.cypress.io/api/commands/debug#Syntax
    
    eg:
    cy.pause()
    cy.get('button').contains('进入租户').click().debug()
    
    ```

    
    

- 运行时的截屏和录屏 

  - ```javascript
  //cypress 默认在测试用例执行失败的时候会自动截图
    .screenshot()
    https://docs.cypress.io/api/commands/screenshot 
    
    .video()
    https://docs.cypress.io/guides/guides/screenshots-and-videos#Videos
    
    usage:
    cy.screenshot()
    cy.get('.post').screenshot()
    ```
    
    
  
- 使用custom commands

  -  Cypress 带有自己的 API，用于创建自定义命令和覆盖现有命令。

  - 改造了以往的PageObject模式

  - ```javascript
    自定义命令，Custom Commands
    https://docs.cypress.io/api/cypress-api/custom-commands 
    
    一般都是定义在cypress/support/commands.js文件中。
    
    语法：
    Cypress.Commands.add(name, callbackFn)
    Cypress.Commands.add(name, options, callbackFn)
    Cypress.Commands.overwrite(name, callbackFn)
    
    //自定义函数login()
    在commands.js文件中：
    Cypress.Commands.add('login', (account, password) => {})
    
    使用方法：
    直接在其它文件中使用cy.login(account,password)即可调用。
    
  ```
    
    

- 数据驱动策略

  - cy.fixture

  - ```javascript
    加载位于文件中的一组固定数据。
    官网位置：
    https://docs.cypress.io/api/commands/fixture
    
    语法：
    cy.fixture(filePath)
    cy.fixture(filePath, encoding)
    cy.fixture(filePath, options)
    cy.fixture(filePath, encoding, options)
    
    demo:
    describe("首页登录",function(){
        it('login',function(){
            cy.fixture('demo/login_users_demo2.json').then((user)=>{
                for(var p in user){  //
                    cy.log(user[p].username)
                    cy.log(user[p].password)
                }
                
            })
        })
    })
    
    //文件路径：fixture/demo/login_users_demo2.json
    [
        {
            "username":"xxx01@datagrand.com",
            "password":"xxx@123456"
        },
        {
            "username":"xxx02@datagrand.com",
            "password":"xxx@123456"
        }
    ]
    
    ```

    

- 环境变量设置

  - Cypress.env

    ```javascript
    https://docs.cypress.io/api/cypress-api/env#Name
    
    默认cypress.json文件中设置：
    {
      "env": {
        "product_v12": "http://rpa-v12.datagrand.com/",
        "product_v11": "http://rpa-v11.datagrand.com/"
      }
    }
    
    也可以在测试套件中设置(测试配置)：
    it('测试配置中设置env',
            {
                env:{
                    "cur_env":"http://rpa-test.datagrand.com",
                    "default_account":"notice@datagrand.com"
                }
            },()=>{
                //打印指定环境变量的值
                cy.log(Cypress.env("cur_env"))
                cy.log(Cypress.env("default_account"))
                //打印所有环境变量
                cy.log(Cypress.env())
     })
    
    ```
    

- 删除等待代码

  - cypress无需显示设置cy.wait()
- 在页面某些元素还没出来的时候，通常我们会添加等待的代码。但是在cypress中，是自动等待的，直到
    元素出现，或者超过了你设置的超时时间（命令和断言重试机制）。

  
  
- 测试运行失败自动重试

  Cypress 重试能力是重要的核心能力之一。重试分为：测试重试、命令和断言重试。

  - 断言重试

    - ```javascript
      重试能力
      
      有很多种情况需要重试功能：
      a.等待DOM更新；
      b.等待后端响应；
      
      重试能力的命令：
      查询的DOM，如cy.get().find().contains().first()等。
      并非每个命令都会重试。当命令可能改变被测应用程序的状态时，不会重试命令，如click()命令。
      
      多个断言时，- 按顺序进行。
      仅重试最后一个命令：仅重试 断言之前的最后一条命令
      
      超时：
      默认情况下，每个重试的命令最多持续 4 秒 - defaultCommandTimeout设置。
      
      超时的设置：
      1、cypress.json 配置文件，设置超时时间。
      2、命令行模式设置：
      cypress run --config defaultCommandTimeout=10000
                                    
      3、cypress官网文档不建议全局更改命令超时。相反，传递单个命令的{ timeout: ms }选项以重试不同的时间段。
      cy.get('.mobile-nav', { timeout: 10000 }).should('be.visible')
      
      禁止重试：
      覆盖超时0将基本上禁用重试命令，因为它将花费 0 毫秒重试。
      cy.get('#ssr-error', { timeout: 0 }).should('not.exist')
      
      ```
      
      
    
  - 测试重试

    - ```javascript
    https://docs.cypress.io/guides/guides/test-retries#Global-Configuration
      //可指定测试运行次数
    //同环境变量一致,可全局配置，在cypress.json配置文件中设置,可局部设置，在测试套件或者用例中设置。
      cypress.json设置：
      {
      	retries:0
      }
      
      在测试套件(测试配置)中：
      describe("test_demo",{retries:0},()=>{...})
      it("test_xx",{retries:0},()=>{...})
      
      ```
      

- 全面的测试报告

  - mocha内置报告器(spec、json、junit)
  - mochawesome
  -  mocha-multi-reporters (混合报告器)

- ```javascript
  mochawesome的配置方式：
  1、配置文件方式（cypress.json）
  2、命令行直接指定参数指方式
  	cypress run --reporter mochawesome ...
    
  
  Mocha报告器：
  https://docs.cypress.io/guides/tooling/reporters
  
  1、安装依赖文件
  npm install --save-dev mochawesome mochawesome-merge mochawesome-report-generator
  
  2、mochawesome的两种配置方式：
    2.1配置文件中cypress.json配置报告器 （默认情况下） 
    {
      "reporter": "mochawesome",
      "reporterOptions": {
        "reportDir": "cypress/results",
        "overwrite": false,
        "html": false,
        "json": true
      }
    }
    2.2命令行模式下的配置：
    npx cypress run --reporter mochawesome \
      --reporter-options reportDir="cypress/results",overwrite=false,html=false,json=true
    
  执行后，会在cypress/results/文件夹下生成mochawesome.json，ochawesome_001.json等文件。
  
  3、我们可以使用mochawesome-merge实用程序将它们组合起来 
  输入命令：
  npx mochawesome-merge "cypress/results/*.json" > mochawesome.json
  
  我们现在可以通过mochawesome.json文件中生成一个组合的HTML报告，输入命令：
  npx marge mochawesome.json
  
  然后，生成漂亮的独立 HTML 报告文件， mochawesome-report/mochawesome.html如下所示，包括所有测试结果、时间信息，甚至测试主体。
  ```

  <img src="/Users/hayleygao/Library/Application Support/typora-user-images/image-20220117102308862.png" alt="image-20220117102308862" style="zoom:20%;" />



### cypress接口测试

cypress支持发送HTTP请求：

```javascript
https://docs.cypress.io/api/commands/request

语法格式：
cy.request(url)
cy.request(url, body)
cy.request(method, url)
cy.request(method, url, body)
cy.request(options)
```

接口测试初体验：

```javascript

describe("首页登录",function(){

    it('登录案例 GET',function(){
            // 使用cy.request(),发送get请求，且可以使用别名
            cy.request('GET','http://rpa-test.datagrand.com').as('homePage')
            cy.get('@homePage').should((response)=>{
                expect(response.status).to.equal(200)    
            })
    })

    it('登录案例 POST',function(){
        cy.request(
            {
                url: 'http://rpa-test.datagrand.com/v2/token?_allow_anonymous=true&selfHandled=yes',
                method: 'POST',
                form:true,
                headers:{
                    "X-Referer": "Console",
                    "Referer": "http://rpa-test.datagrand.com/",
                    "Content-Type": "multipart/form-data",
                    "Accept": "application/json, text/plain, */*",
                    "Origin": "http: //rpa-test.datagrand.com",
                    "Host": "rpa-test.datagrand.com ",
                    "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.110 Safari/537.36"
                },
                body:{
                    "accountEmail": "gaoxiaoyan%40datagrand.com",
                    "password": "b29a8e35a7eeb51fd42c6abfb93597d9"
                }
            }
        ).then((response)=>{
            expect(response.status).to.eq(200)
        })
    })
})

```



### cypress插件的使用

Cypress提供了一种支持和扩展cypress行为的方法,就是可以安装插件。

```javascript
插件的地址：
https://docs.cypress.io/plugins/directory

一般的步骤：
1、安装插件
npm install --save-dev cypress-file-upload
2、使用时，使用import 导入，如cypress-xpath。
import "cypress-xpath"
```



- cypress上传

```javascript
上传案例：
https://github.com/abramenal/cypress-file-upload

it('验证文件上传功能 日历上传', () => {
      //访问日历管理部分
      //拖动滚动条到最下方
      cy.xpath('/html/body/rpa-root/div/div/layout-default/bixi-layout/div/bixi-layout-menu/ul')
      .scrollTo('bottom')
      
      cy.contains('日历管理').click()

      //点击新建日历
      cy.contains("新建日历").click()

      //填写日历名称
      cy.get('input[placeholder="请输入日历名称"]').type("demo_22011101_calendar")

      //上传日历文件
      let file = "file/calendar_template.csv"; //这里使用了相对路径，文件在fixture目录下。
      cy.get('input[type="file"]').attachFile(file)

      cy.contains("保存").click()
    }
 )
```



- cypress下载


```javascript
插件地址：
https://github.com/Xvier/cypress-downloadfile

安装插件：
npm install cypress-downloadfile

it('下载 demo',()=>{
    cy.downloadFile('https://gimg2.baidu.com/image_search/xxx.png,'downloads','example.jpg')
})

```



- cypress-xpath 插件

```javascript

https://github.com/cypress-io/cypress-xpath

使用npm包直接进行下载与安装。
npm install cypress-xpath

使用的时候，使用import 导入即可。
import "cypress-xpath"

//点击登录按钮
cy.xpath("/html/body/rpa-root/div/div/rpa-login/div/div/div[2]/div/div[2]/div/div[1]/div[2]/form/nz-form-item[4]/button").click()

```



### 命令行模式

命令行模式运行cypress

```javascript
官网地址：
https://docs.cypress.io/guides/guides/command-line#cypress-run
```

常用的两个命令：

- cypress.run()
- cypress.open()

```javascript
假设已经安装好了cypress相关。安装后，您将能够从“项目根目录”执行本文档中的所有命令。
可以使用yarn或者npm、npx
如：
yarn cypress run
npx cypress run 
```

```javascript
cypress run
运行 Cypress 测试直至完成。默认情况下，cypress run将无头运行所有测试。

语法格式：
cypress run [options]

cypress run  --browser chrome  --headed   --reporter json //运行用例，且以指定的chrome浏览器，显示浏览器执行，生成json格式的报告。
cypress run --reporter junit --reporter-options mochaFile=result.xml,toConsole=true   //运行用例，指定junit格式的报告，且指定结果文件名称为result.xml，将内容显示在console.

```

```javascript
cypress open
打开cypress测试运行器。

语法格式：
cypress open [options]

npx cypress open    //打开/启动 运行器
npx cypress open -b chrome  //打开运行器，且添加chrome浏览器为可用浏览器列表。
npx cypress open -b firefox //打开运行器，且添加firefox浏览器为可用浏览器列表。

------------多个浏览器，可以实现跨浏览器的测试----------------------------

默认情况下，赛普拉斯会自动查找并允许您使用系统上安装的浏览器
“浏览器”选项允许您指定与 Cypress 一起使用的自定义浏览器的路径：
如果找到，指定的浏览器将添加到 Cypress Test Runner 的可用浏览器列表中。

目前，仅支持 Chrome 家族中的浏览器（包括新的基于 Chromium 的 Microsoft Edge 和 Brave）和 Firefox。
```

```javascript
其它命令：

cypress info  //打印有关 Cypress 和当前环境的信息
cypress verify //验证 Cypress 是否已正确安装并且是可执行的
cypress version  //打印已安装的 Cypress 二进制版本、Cypress 软件包版本、用于构建 Cypress 的 Electron 版本以及捆绑的 Node 版本。

cypress cache [command] //用于管理全局 Cypress 缓存的命令
cypress cache path  //打印path到 Cypress 缓存文件夹。
cypress cache list  //打印所有已安装的 Cypress 版本。
cypress cache clear  //清除赛普拉斯缓存的内容。
```



## 七、其它相关

### 持续集成

Cypress与所有持续集成 (CI) 提供商和系统兼容。这里不再展开描述。

```javascript
https://docs.cypress.io/guides/continuous-integration/ci-provider-examples#Guides
```



### Cypress与electron

目前，cypress没有正式支持 Electron.js 应用程序，官网提供了一个早期的测试版和相应的插件，有兴趣的同学可以尝试探索。

```javascript
https://www.cypress.io/blog/2019/09/26/testing-electron-js-applications-using-cypress-alpha-release/
```








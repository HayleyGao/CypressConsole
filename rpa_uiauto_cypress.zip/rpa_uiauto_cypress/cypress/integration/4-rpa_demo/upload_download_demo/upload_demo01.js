
import 'cypress-xpath'


context('文件上传 demo', () => {
  beforeEach(()=>{
      cy.visit("/")
      //用户名
      cy.get('.ng-tns-c53-1 > .ant-input')
      .type('gaoxiaoyan@datagrand.com')
      .should('have.value','gaoxiaoyan@datagrand.com')

      //密码框
      cy.get('.ng-tns-c53-2 > .ant-input')
      .type('Gaoxiaoyan9533')
      .should('have.value','Gaoxiaoyan9533')

      //登录按钮
      cy.get('.btn-login').click()

     //选择租户
      cy.get('body').then(($body)=>{
          if($body.text().includes('选择租户')){ //find()或者includes()方法
              cy.log('选择租户') //输出日志
              cy.get('button').contains('进入租户').click() //contains() 文本方式定位

          }else{
              cy.log('不选择租户，go on!')
          }
      })

      //进入console的dashboard
      cy.url().should('contain','#/dashboard')

      //进入任务管理
      //点击任务管理菜单栏
      cy.get('.menu > :nth-child(3) > span').click()
      cy.url().should('include','rpa/task-list')

    }
  )
  


  it('验证文件上传功能 日历上传', () => {
      //访问日历管理部分
      //拖动滚动条到最下方
      cy.xpath('/html/body/rpa-root/div/div/layout-default/bixi-layout/div/bixi-layout-menu/ul')
      .scrollTo('bottom')
      
      cy.contains('日历管理').click()


      //点击新建日历
      cy.contains("新建日历").click()

      //填写日历名称
      cy.get('input[placeholder="请输入日历名称"]').type("demo_22011101_calendar")

      //上传日历文件
      let file = "file/calendar_template.csv"; //这里使用了相对路径，文件在fixture目录下。
      cy.get('input[type="file"]').attachFile(file)

      cy.contains("保存").click()
    }
  )

 
})



//cy.[command]命令是异步执行的

//https://docs.cypress.io/guides/core-concepts/introduction-to-cypress#Commands-Are-Asynchronous


it('does not work as we expect', () => {
    cy.visit('/my/resource/path') // Nothing happens yet
  
    cy.get('.awesome-selector') // Still nothing happening
      .click() // Nope, nothing
  
    // Cypress.$ is synchronous, so evaluates immediately
    // there is no element to find yet because
    // the cy.visit() was only queued to visit
    // and did not actually visit the application
    let el = Cypress.$('.new-el') // evaluates immediately as []
  
    if (el.length) {
      // evaluates immediately as 0
      cy.get('.another-selector')
    } else {
      // this will always run
      // because the 'el.length' is 0
      // when the code executes
      cy.get('.optional-selector')
    }
  })
  
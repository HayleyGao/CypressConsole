//env设置 测试
//https://www.cnblogs.com/poloyy/p/13056393.html
//https://docs.cypress.io/api/cypress-api/env#No-Arguments



context('测试环境变量的设置',()=>{
    it('cypress.json env 中设置',()=>{
        //打印某个环境变量的值
        cy.log(Cypress.env('accountEmail'))
        cy.log(Cypress.env('password'))
        //打印所有环境变量
        cy.log(Cypress.env())

    })
})


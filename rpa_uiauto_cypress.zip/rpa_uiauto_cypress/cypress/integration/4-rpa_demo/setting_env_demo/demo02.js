//env设置 测试
//https://www.cnblogs.com/poloyy/p/13056393.html
//https://docs.cypress.io/api/cypress-api/env#No-Arguments
// Cypress.env；OS environment variables设置；

import "cypress-xpath"

context('测试环境变量的设置',()=>{
    it('cypress.json env 中设置',()=>{
        //打印某个环境变量的值
        cy.log(Cypress.env('accountEmail'))
        cy.log(Cypress.env('password'))
        //打印所有环境变量
        cy.log(Cypress.env())

    })
    

    it("环境变量切换环境测试 baseUrl",()=>{
        // cy.visit("http://rpa-test.datagrand.com")
        cy.visit("") //因为在cypress.json中设置了baseUrl
        cy.xpath("/html/body/rpa-root/div/div/rpa-login/div/div/div[2]/div/div[2]/div/div[1]/div[2]/form/nz-form-item[1]/nz-form-control/div/div/nz-input-group/input").type("gaoxiaoyan@datagrand.com").should('have.value','gaoxiaoyan@datagrand.com')
        cy.xpath("/html/body/rpa-root/div/div/rpa-login/div/div/div[2]/div/div[2]/div/div[1]/div[2]/form/nz-form-item[2]/nz-form-control/div/div/nz-input-group/input").type("Gaoxiaoyan9533").should('have.value','Gaoxiaoyan9533')
        cy.xpath("/html/body/rpa-root/div/div/rpa-login/div/div/div[2]/div/div[2]/div/div[1]/div[2]/form/nz-form-item[4]/button").click()

        cy.xpath("/html/body/rpa-root/div/div/rpa-login/div/div/div[2]/div/div[2]/div/div[2]/div[2]/div[2]/button").click()
        cy.url().should('include','#/dashboard')

     
    })

    it("环境变量切换环境测试 env:test_url",()=>{
        // cy.visit("http://rpa-test.datagrand.com")
        cy.visit(Cypress.env("test_url")) //因为在cypress.json中设置了baseUrl
        cy.xpath("/html/body/rpa-root/div/div/rpa-login/div/div/div[2]/div/div[2]/div/div[1]/div[2]/form/nz-form-item[1]/nz-form-control/div/div/nz-input-group/input").type("gaoxiaoyan@datagrand.com").should('have.value','gaoxiaoyan@datagrand.com')
        cy.xpath("/html/body/rpa-root/div/div/rpa-login/div/div/div[2]/div/div[2]/div/div[1]/div[2]/form/nz-form-item[2]/nz-form-control/div/div/nz-input-group/input").type("Gaoxiaoyan9533").should('have.value','Gaoxiaoyan9533')
        cy.xpath("/html/body/rpa-root/div/div/rpa-login/div/div/div[2]/div/div[2]/div/div[1]/div[2]/form/nz-form-item[4]/button").click()

        cy.xpath("/html/body/rpa-root/div/div/rpa-login/div/div/div[2]/div/div[2]/div/div[2]/div[2]/div[2]/button").click()
        cy.url().should('include','#/dashboard')

        // cy.xpath("/html/body/rpa-root/div/div/layout-default/bixi-layout/div/bixi-layout-menu/ul/li[3]/span").click()
        // cy.url().should('include','rpa/task-list')
    })

    it("环境变量切换环境测试 env:product_v12",()=>{
        // cy.visit("http://rpa-test.datagrand.com")
        cy.visit(Cypress.env("product_v12")) //因为在cypress.json中设置了baseUrl
       
    })



})






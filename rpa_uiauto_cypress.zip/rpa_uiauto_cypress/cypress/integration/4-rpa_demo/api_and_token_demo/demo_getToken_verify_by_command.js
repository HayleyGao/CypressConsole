//  Cypress.Commands，自定义api
//https://docs.cypress.io/api/cypress-api/custom-commands#Syntax 



describe('getToken_byCommand verify',()=>{
    it('get token',()=>{
        cy.getToken()
        cy.log('token',sessionStorage.getItem('This_Token'))
    })
})








  

    


   
    



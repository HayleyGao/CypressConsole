//  Cypress.Commands，自定义api
// https://docs.cypress.io/api/cypress-api/custom-commands#Parent-Commands  //创建用户模块



describe('getToken verify',()=>{
    before('获取token',()=>{
        cy.getToken()
        //cy.log(sessionStorage.getItem('This_Token'))
        
    })


    it('get robotsList api',()=>{
        cy.request({
            url:"http://rpa-test.datagrand.com/v2/robots?page=0&perPage=10",
            method:'GET',
            headers:{
                "X-Tenant": "0cc21ce8-f16c-11e9-9f12-0242ac120003",
                "X-Referer": "Console",
                "Referer": "http://rpa-test.datagrand.com/",
                "Authorization":"Bearer "+sessionStorage.getItem('This_Token')
            }
        }).then((response)=>{
            expect(response.status).to.be.eq(200)
            cy.log(response.body)
        })
    })

    after(()=>{
        // cy.clearLocalStorage()
        cy.log('this is after.')
    })

    
})








  

    


   
    



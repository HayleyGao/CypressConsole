import "cypress-xpath"

//cy.request()
//https://docs.cypress.io/api/commands/request#Arguments


describe("首页登录",function(){
    
    it('获取token',function(){
        cy.request(
            {
                url: 'http://rpa-test.datagrand.com/v2/token?_allow_anonymous=true&selfHandled=yes',
                method: 'POST',
                headers:{
                    "X-Referer": "Console",
                    "Referer": "http://rpa-test.datagrand.com/",
                    "Content-Type": "multipart/form-data",
                    "Accept": "application/json, text/plain, */*",
                    "Origin": "http: //rpa-test.datagrand.com",
                    "Host": "rpa-test.datagrand.com ",
                    "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.110 Safari/537.36"
                },
                form:true,//这项，是否将body值转换为 URL 编码的内容并设置x-www-form-urlencoded标题。
                body:{
                    "accountEmail": "gaoxiaoyan%40datagrand.com",
                    "password": "b29a8e35a7eeb51fd42c6abfb93597d9"
                },
                params:{
                    "_allow_anonymous": "true",
                    "selfHandled": "yes"
                }           
            }
        ).then((response)=>{
            expect(response.status).to.eq(200)
            cy.log(response.body)
            //cy.log(response.body.result.token)

            var cur_token=response.body.result.token
            cy.log('cur_token:','Bearer '+cur_token)

        })
    })

  

    


   
    
})


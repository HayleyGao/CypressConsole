import "cypress-xpath"

describe("首页登录",function(){
    beforeEach(()=>{
        cy.visit("http://rpa-test.datagrand.com")
        
    })
    it('login',function(){
        cy.xpath("/html/body/rpa-root/div/div/rpa-login/div/div/div[2]/div/div[2]/div/div[1]/div[2]/form/nz-form-item[1]/nz-form-control/div/div/nz-input-group/input")
        .type("testapi@chacuo.net")
        .should('have.value','testapi@chacuo.net')

        cy.xpath("//input[@type='password']")
        .type("testapi@123")
        .should('have.value','testapi@123')

        cy.xpath("//button[@type='submit']").click()

        cy.url().should('include','dashboard')
    })

})


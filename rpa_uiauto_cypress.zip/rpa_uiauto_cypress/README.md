**此项目为RPA UI自动化（cypress）**
使用说明如下：

1、安装依赖环境node.js：

由于cypress是依赖于node.js运行，所以需要本地先安装好node.js。

node.js的安装地址：
http://nodejs.cn/download/

由于npm已经集成在新版的Node.js中了，输入以下命令验证node.js和npm的安装是否成功，如：

node -v

v16.13.1

npm -v

8.1.2

2、安装cypress，通过npm:

npm install cypress --save-dev

关于node.js和cypress的安装，可参考：
https://www.cnblogs.com/poloyy/p/12919454.html


3、cypress的启动：
进入 Cypress安装目录\node_modules\.bin 目录，输入：
cypress open

若遇到启动报错的情况，可参考：


http://t.zoukankan.com/51testing-p-13061186.html

具体：

a.进入 Cypress安装目录\package.json文件中的SCript下，添加：
"open":"cypress open"

b.在 Cypress安装目录 下，输入命令行：npm run open 启动。


4、cypress的case添加：
在\rpa_uiauto_cypress\cypress\integration 路径下，可以新建文件夹和文件，填写case。

填写成功之后，在已经启动的cypress桌面窗口，双击对应的case文件，查看运行效果。


5、cypress官网：

https://docs.cypress.io/guides/overview/why-cypress

6、tips:

当遇通过到xpath定位时，cypress安装xpath依赖库：

npm install cypress-xpath








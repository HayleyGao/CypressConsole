# [cypress](https://www.cypress.io/)

## 前端自动化测试框架

### cypress框架简介

- 基于JavaScript的前端测试工具
- cypress是自集成的，提供了一整套端到端测试，安装后可直接创建、编写、运行测试用例，且每一步都支持回看。
- 不仅支持UI层测试，且还支持测试金字塔模型的所有测试：UI测试、集成测试、单元测试
- 底层不采用webdriver

### [前端测试框架对比（cypress VS Selenium/webdriver）](https://www.sohu.com/a/459758304_185201)

- 原理不同

	- Selenium/webdriver使用JSON Wire Protocol
	- Cypress框架完全自有，不使用JSON Wire Protocol

- 运行层面不同

	- selenium/webdriver驱动，运行在浏览器之上
	- cypress驱动，运行在浏览器之内

- 完备的框架 VS Library

	- cypress 开箱即用，All in one

	  All in one特性，开箱即用。
	  
	  底层框架不需要webdriver，自带断言库，自带Mock Server.
	  
		- 
底层框架不需要webdriver
		- 自带断言库
		- 自带Mock Server

	- selenium/webdriver 是Library

### cypress的优点/特性、局限

- 八大特性/优点

  - 时间穿梭
  - 实时重新加载
  - Spies、Stubs和Clock
  - 运行结果一致性
  - 可调试性
  - 自动等待
  - 网络流量控制
  - 截图和视频

- 缺点

	- 仅支持JavaScript
	- 不支持APP端（仅支持web）
	- 部分功能要收费（dashboard/仪表盘）

## cypress基础知识

### 样例初体验

```javascript
describe('首页测试', () => {
    it('访问首页', () => {
      cy.visit('https://www.baidu.com/')
      cy.get('input[name="wd"]').eq(0).type('test')
      cy.get('input[id="su"]').click()
    })
})
```


### 测试框架文件结构分析

- cypress默认文件结构

  - Fixture测试夹具
  - Integration/TestFile测试文件
  - PluginsFile插件
  - SupportFile支持文件
  - 

- [自定义cypress](https://www.cnblogs.com/poloyy/p/13024996.html)

	- 更改全局配置
	- 更改超时设置
	- 更改文件夹结构
	- 动态配置

- 重试机制
- 测试报告

### 测试用例的组织和编写

- [Mocha介绍](https://mochajs.org/)

	- [是JavaScript的测试框架（类似与python 的unittest）,运行在node.js和浏览器中。](https://www.liaoxuefeng.com/wiki/1022910821149312/1101741181366880)

	- 支持TDD,BDD等，默认是BDD风格

		- TDD
		- BDD

	- cypress继承且扩展了Mocha对异步的支持
	- cypress的底层是Mocha和chai.js，且cypress采用了BDD风格。
	- Mocha中的异步与同步

		- Mocha异步代码（async）
		- Mocha同步代码(sync)

- 钩子函数（Hook）

	- 主要是指：before、after、beforeEach和afterEach

- 排除或包含测试用例
- 动态忽略测试用例
- 动态生成测试用例
- [断言](https://docs.cypress.io/guides/references/assertions)

	- Cypress 捆绑了流行的Chai断言库

		- BDD

			- expect/should

		- TDD

			- assert

	- [常见元素断言的列表](https://docs.cypress.io/guides/references/assertions#Common-Assertions)

	  length
	  class
	  value
	  text
	  visible
	  exist
	  css
	  enable/disbale
	  checked/selected
	  
	  
### 与元素的交互

- cypress元素定位选择器
- cypress与页面元素交互

### 执行方式

- 命令行运行cypress

	- cypress open
	- cypress run

- 测试运行器（Test Runner）

## [cypress最佳实践/关键点](https://docs.cypress.io/api/table-of-contents)

### cypress典型使用场景

- 设置全局URL
- 避免访问多个站点
- 删除等待代码
- 停用条件测试
- 实时调试和中断
- 运行时的截屏和录屏 
- 断言最佳实践
- 改造PageObject模式
- 使用custom commands
- 数据驱动策略
- 环境变量设置
- 测试运行最佳实践
- 测试运行失败自动重试
- 全面的测试报告
- cypress连接DB

### [cypress接口测试](https://docs.cypress.io/api/commands/request)

### Mock Server

- 自定义Mock Server
- cypress 自带Mock

### 模块API

- cypress.run()
- cypress.open()

## 持续集成

### cypress并行执行测试

### Jenkins持续集成实践

